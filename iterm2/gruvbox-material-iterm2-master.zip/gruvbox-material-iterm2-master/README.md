# Gruvbox Material for iTerm2

![](gruvbox-material-iterm2.png)

Port of [Gruvbox Material theme](https://github.com/gruvbox-material/gruvbox-material) to iTerm2
